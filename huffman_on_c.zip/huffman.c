#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SYMBOL_COUNT 256
#define MAX_CODE_LEN 256

typedef struct HuffNode {
    unsigned char value;
    unsigned long long count;
    struct HuffNode *left, *right;
} HuffNode;

typedef struct {
    HuffNode* array[SYMBOL_COUNT];
    int count;
} Heap;

typedef struct {
    char bits[MAX_CODE_LEN];
    int length;
} BitCode;

void heap_insert(Heap* h, HuffNode* node) {
    int idx = h->count++;
    while (idx > 0) {
        int parent = (idx - 1) / 2;
        if (h->array[parent]->count <= node->count) break;
        h->array[idx] = h->array[parent];
        idx = parent;
    }
    h->array[idx] = node;
}

HuffNode* heap_remove_min(Heap* h) {
    HuffNode* min = h->array[0];
    HuffNode* last = h->array[--h->count];
    int idx = 0;
    while (1) {
        int l = 2 * idx + 1, r = 2 * idx + 2, smallest = idx;
        if (l < h->count && h->array[l]->count < h->array[smallest]->count) smallest = l;
        if (r < h->count && h->array[r]->count < h->array[smallest]->count) smallest = r;
        if (smallest == idx) break;
        h->array[idx] = h->array[smallest];
        idx = smallest;
    }
    h->array[idx] = last;
    return min;
}

void assign_codes(HuffNode* node, BitCode* codes, char* temp, int len) {
    if (!node->left && !node->right) {
        temp[len] = '\0';
        strcpy(codes[node->value].bits, temp);
        codes[node->value].length = len;
        return;
    }
    if (node->left) {
        temp[len] = '0';
        assign_codes(node->left, codes, temp, len + 1);
    }
    if (node->right) {
        temp[len] = '1';
        assign_codes(node->right, codes, temp, len + 1);
    }
}

void free_tree(HuffNode* root) {
    if (!root) return;
    free_tree(root->left);
    free_tree(root->right);
    free(root);
}

int main() {
    FILE *fin = fopen("input.txt", "rb");
    if (!fin) {
        perror("input.txt");
        return 1;
    }
    unsigned long long frequency[SYMBOL_COUNT] = {0};
    int ch;
    while ((ch = fgetc(fin)) != EOF) frequency[(unsigned char)ch]++;
    rewind(fin);

    Heap h = {.count = 0};
    for (int i = 0; i < SYMBOL_COUNT; ++i) {
        if (frequency[i]) {
            HuffNode* n = malloc(sizeof(HuffNode));
            n->value = (unsigned char)i;
            n->count = frequency[i];
            n->left = n->right = NULL;
            heap_insert(&h, n);
        }
    }
    while (h.count > 1) {
        HuffNode *a = heap_remove_min(&h), *b = heap_remove_min(&h);
        HuffNode* parent = malloc(sizeof(HuffNode));
        parent->value = 0;
        parent->count = a->count + b->count;
        parent->left = a;
        parent->right = b;
        heap_insert(&h, parent);
    }
    HuffNode* root = h.count ? heap_remove_min(&h) : NULL;

    BitCode table[SYMBOL_COUNT] = {0};
    char buffer[MAX_CODE_LEN];
    if (root) assign_codes(root, table, buffer, 0);

    FILE *fout = fopen("encoded.bin", "wb");
    if (!fout) {
        perror("encoded.bin");
        return 2;
    }

    // Запись заголовка (частоты)
    int used = 0;
    for (int i = 0; i < SYMBOL_COUNT; ++i)
        if (frequency[i]) ++used;
    fwrite(&used, sizeof(int), 1, fout);
    for (int i = 0; i < SYMBOL_COUNT; ++i)
        if (frequency[i]) {
            unsigned char c = (unsigned char)i;
            fwrite(&c, 1, 1, fout);
            fwrite(&frequency[i], sizeof(unsigned long long), 1, fout);
        }

    // Кодирование и запись
    unsigned char out_byte = 0;
    int bits_used = 0;
    while ((ch = fgetc(fin)) != EOF) {
        BitCode* b = &table[(unsigned char)ch];
        for (int i = 0; i < b->length; ++i) {
            out_byte = (out_byte << 1) | (b->bits[i] - '0');
            bits_used++;
            if (bits_used == 8) {
                fwrite(&out_byte, 1, 1, fout);
                bits_used = 0;
                out_byte = 0;
            }
        }
    }
    if (bits_used > 0) {
        out_byte <<= (8 - bits_used);
        fwrite(&out_byte, 1, 1, fout);
    }

    fclose(fin);
    fclose(fout);
    free_tree(root);

    // Декодирование сразу
    fin = fopen("encoded.bin", "rb");
    fout = fopen("decoded.txt", "wb");
    if (!fin || !fout) {
        perror("decode I/O");
        return 3;
    }

    fread(&used, sizeof(int), 1, fin);
    memset(frequency, 0, sizeof(frequency));
    for (int i = 0; i < used; ++i) {
        unsigned char c;
        unsigned long long f;
        fread(&c, 1, 1, fin);
        fread(&f, sizeof(unsigned long long), 1, fin);
        frequency[c] = f;
    }

    h.count = 0;
    for (int i = 0; i < SYMBOL_COUNT; ++i) {
        if (frequency[i]) {
            HuffNode* n = malloc(sizeof(HuffNode));
            n->value = (unsigned char)i;
            n->count = frequency[i];
            n->left = n->right = NULL;
            heap_insert(&h, n);
        }
    }
    while (h.count > 1) {
        HuffNode *a = heap_remove_min(&h), *b = heap_remove_min(&h);
        HuffNode* parent = malloc(sizeof(HuffNode));
        parent->value = 0;
        parent->count = a->count + b->count;
        parent->left = a;
        parent->right = b;
        heap_insert(&h, parent);
    }
    root = h.count ? heap_remove_min(&h) : NULL;
    HuffNode* current = root;

    ch = 0;
    bits_used = 0;
    while ((ch = fgetc(fin)) != EOF) {
        for (int i = 7; i >= 0; --i) {
            int bit = (ch >> i) & 1;
            current = bit ? current->right : current->left;
            if (current && !current->left && !current->right) {
                fputc(current->value, fout);
                current = root;
            }
        }
    }
    fclose(fin);
    fclose(fout);
    free_tree(root);
    return 0;
}
